Populistic Optimization by Genetic Selection

A compo submission for Ludum dare 44 by Erik Hallin

You are in dept and you need to repay in souls. A creature have been created in your image. It will breed and try to create a small society. However, you can select which properties of the creatures that will be passed on to future generations. A well-growing population allows you to harvest souls to pay your dept.

Controls
LMB - Select Creature
RMB - Sacrifice Creature
Space - See Help info

Help
The population will grow faster with more productive creatures, resulting in new creatures moving in.
Note that the likelihood of creatures to have offspring increases with less time spent working.