#ifndef DEF_H
#define DEF_H

const float _pi=3.141592;
const float _deg2rad=0.01745329252;

const float _time_dif=0.01;//60 fps

const float _break_time=10;
const float _work_time=10;
const float _birth_time=20;
const float _crime_time=10;
const float _shake_time=0.5;


#endif
