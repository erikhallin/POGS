#ifndef SOUND_LIST_H
#define SOUND_LIST_H

//List of all in game sounds

enum sounds
{
    wav_flash1=0,
    wav_flash2,
    wav_flash3,
    wav_background,
    wav_spawn,
    wav_hurt,
    wav_build
};

#endif
